# Karteikasten dialogue token optimization

- `index.html`: shorter prompt for custom OpenAI-compatible APIs.
- `index.ts`: shorter Groq dialogue system prompt, one previous turn instead of two, lower dialogue completion cap (240 tokens), and leaner input-token reservation estimate.

Deploy the Edge Function from `index.ts` and publish `index.html` to GitHub Pages. Daily quotas remain enabled. These changes reduce token use; they do not raise Groq's separate TPM limit. Test a new dialogue after deployment.
